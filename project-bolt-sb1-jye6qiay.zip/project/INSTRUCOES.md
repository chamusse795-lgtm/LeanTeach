# LCSOLUCTIONSMIDIA.MKT - Landing Page

Landing page de alta conversão otimizada para redes móveis em Moçambique.

## Configuração do Número de WhatsApp

Para configurar o número de WhatsApp da sua empresa, edite os seguintes arquivos:

1. **src/components/Hero.tsx** (linha 4)
2. **src/components/Services.tsx** (linha 4)
3. **src/components/Footer.tsx** (linha 4)
4. **src/components/FloatingWhatsApp.tsx** (linha 4)

Substitua `'258840000000'` pelo seu número no formato internacional (sem espaços ou símbolos):
- Exemplo: `'258840000000'` para Moçambique
- Formato: Código do país (258) + DDD + Número

## Configuração de Redes Sociais

No arquivo **src/components/Footer.tsx**, atualize os links do Instagram e Facebook (linhas 44-56).

## Características da Landing Page

✅ Mobile-first (otimizada para Vodacom/Tmcel)
✅ Botão flutuante de WhatsApp em todas as seções
✅ Design em Azul profissional, Branco e detalhes em Amarelo
✅ Fonte Poppins para leitura rápida
✅ 3 pacotes de serviços prontos
✅ Galeria de portfólio
✅ CTAs estratégicos em cada seção

## Como Usar

1. Publique o link na Bio do Instagram e Facebook
2. Use em anúncios patrocinados
3. Compartilhe diretamente com clientes potenciais

O site foi desenhado para converter visitantes em conversas no WhatsApp!
