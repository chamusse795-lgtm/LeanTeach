import Hero from './components/Hero';
import Services from './components/Services';
import WhyUs from './components/WhyUs';
import Portfolio from './components/Portfolio';
import Footer from './components/Footer';
import FloatingWhatsApp from './components/FloatingWhatsApp';

function App() {
  return (
    <div className="min-h-screen">
      <Hero />
      <Services />
      <WhyUs />
      <Portfolio />
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}

export default App;
