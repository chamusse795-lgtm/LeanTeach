import { MapPin, TrendingUp, MessageCircle } from 'lucide-react';

export default function WhyUs() {
  const reasons = [
    {
      icon: MapPin,
      title: 'Foco no Local',
      description: 'Entendemos o mercado de Maputo, Matola e províncias',
      color: 'text-blue-600'
    },
    {
      icon: TrendingUp,
      title: 'Direto ao Ponto',
      description: 'Menos teoria, mais vendas no seu bolso',
      color: 'text-orange-500'
    },
    {
      icon: MessageCircle,
      title: 'Suporte via WhatsApp',
      description: 'Atendimento rápido e sem complicações',
      color: 'text-yellow-600'
    }
  ];

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-blue-900 mb-4">
          Por que a LCSOLUCTIONSMIDIA.MKT?
        </h2>
        <p className="text-center text-gray-600 mb-12 text-lg max-w-2xl mx-auto">
          Somos mais que uma agência de design. Somos parceiros do seu crescimento.
        </p>

        <div className="grid md:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all text-center"
            >
              <div className="flex justify-center mb-6">
                <div className="bg-blue-50 w-20 h-20 rounded-full flex items-center justify-center">
                  <reason.icon size={40} className={reason.color} />
                </div>
              </div>

              <h3 className="text-2xl font-bold text-blue-900 mb-3">
                {reason.title}
              </h3>

              <p className="text-gray-700 leading-relaxed">
                {reason.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
