import { MessageCircle } from 'lucide-react';

export default function Hero() {
  const whatsappNumber = '258835267196';
  const whatsappMessage = encodeURIComponent('Olá! Quero crescer meu negócio com a LCSOLUCTIONSMIDIA.MKT');
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 text-white px-4 py-20">
      <div className="absolute inset-0 opacity-10">
        <img
          src="https://images.pexels.com/photos/4065876/pexels-photo-4065876.jpeg?auto=compress&cs=tinysrgb&w=1920"
          alt="Background"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
          Criamos o Design que traz <span className="text-yellow-400">Clientes</span> para o seu Negócio em Moçambique
        </h1>

        <p className="text-xl md:text-2xl mb-8 text-blue-100 leading-relaxed">
          Posters, Sites Simples e Gestão de Redes Sociais com foco em vendas via WhatsApp
        </p>

        <a
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-3 bg-yellow-500 hover:bg-yellow-600 text-blue-900 font-bold text-lg px-8 py-4 rounded-full transition-all transform hover:scale-105 shadow-2xl"
        >
          <MessageCircle size={28} />
          QUERO CRESCER MEU NEGÓCIO
        </a>

        <p className="mt-6 text-sm text-blue-200">
          Atendimento rápido via WhatsApp • Resultados reais para o seu bolso
        </p>
      </div>
    </section>
  );
}
