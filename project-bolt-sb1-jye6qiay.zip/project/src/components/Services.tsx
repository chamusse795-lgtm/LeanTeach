import { Package, Globe, Award, MessageCircle } from 'lucide-react';

export default function Services() {
  const whatsappNumber = '258835267196';

  const services = [
    {
      icon: Package,
      name: 'Pack Digital Express',
      includes: '5 Posts + 2 Flyers de Promoção',
      idealFor: 'Restaurantes e Lojas',
      color: 'bg-orange-500',
      message: 'Quero saber mais sobre o Pack Digital Express'
    },
    {
      icon: Globe,
      name: 'Presença Web',
      includes: 'Landing Page + Botão WhatsApp',
      idealFor: 'Prestadores de Serviços',
      color: 'bg-blue-600',
      message: 'Quero saber mais sobre Presença Web'
    },
    {
      icon: Award,
      name: 'Identidade Pro',
      includes: 'Logotipo + Cartão Visita + Capas',
      idealFor: 'Novos Negócios',
      color: 'bg-yellow-500',
      message: 'Quero saber mais sobre Identidade Pro'
    }
  ];

  return (
    <section className="py-20 px-4 bg-white" id="servicos">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-blue-900 mb-4">
          Nossos Serviços
        </h2>
        <p className="text-center text-gray-600 mb-12 text-lg">
          Pacotes prontos para impulsionar seu negócio
        </p>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-xl hover:shadow-2xl transition-all p-8 border-2 border-gray-100 hover:border-blue-200"
            >
              <div className={`${service.color} w-16 h-16 rounded-xl flex items-center justify-center mb-6`}>
                <service.icon size={32} className="text-white" />
              </div>

              <h3 className="text-2xl font-bold text-blue-900 mb-4">
                {service.name}
              </h3>

              <div className="space-y-3 mb-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm font-semibold text-blue-700 mb-1">O que inclui:</p>
                  <p className="text-gray-800">{service.includes}</p>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg">
                  <p className="text-sm font-semibold text-yellow-700 mb-1">Ideal para:</p>
                  <p className="text-gray-800">{service.idealFor}</p>
                </div>
              </div>

              <a
                href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(service.message)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full bg-blue-900 hover:bg-blue-800 text-white font-bold py-3 rounded-lg transition-all"
              >
                <MessageCircle size={20} />
                Solicitar Orçamento
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
