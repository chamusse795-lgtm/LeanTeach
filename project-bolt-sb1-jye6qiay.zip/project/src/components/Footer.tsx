import { MessageCircle, Instagram, Facebook } from 'lucide-react';

export default function Footer() {
  const whatsappNumber = '258835267196';
  const whatsappMessage = encodeURIComponent('Preciso de uma arte profissional! Vamos conversar?');
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  return (
    <footer className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 text-white">
      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Precisa de uma arte profissional <span className="text-yellow-400">ainda hoje?</span>
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Clique abaixo e fale com nossa equipe agora!
          </p>

          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-yellow-500 hover:bg-yellow-600 text-blue-900 font-bold text-lg px-10 py-5 rounded-full transition-all transform hover:scale-105 shadow-2xl"
          >
            <MessageCircle size={28} />
            FALAR COM CONSULTOR NO WHATSAPP
          </a>
        </div>

        <div className="border-t border-blue-700 pt-8 text-center">
          <h3 className="text-2xl font-bold mb-4">LCSOLUCTIONSMIDIA.MKT</h3>
          <p className="text-blue-200 mb-6">
            Design que traz clientes para o seu negócio em Moçambique
          </p>

          <div className="flex justify-center gap-6 mb-6">
            <a
              href="#"
              className="w-12 h-12 bg-blue-700 hover:bg-blue-600 rounded-full flex items-center justify-center transition-all"
              aria-label="Instagram"
            >
              <Instagram size={24} />
            </a>
            <a
              href="#"
              className="w-12 h-12 bg-blue-700 hover:bg-blue-600 rounded-full flex items-center justify-center transition-all"
              aria-label="Facebook"
            >
              <Facebook size={24} />
            </a>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 bg-yellow-500 hover:bg-yellow-600 rounded-full flex items-center justify-center transition-all"
              aria-label="WhatsApp"
            >
              <MessageCircle size={24} className="text-blue-900" />
            </a>
          </div>

          <p className="text-sm text-blue-300">
            © 2025 LCSOLUCTIONSMIDIA.MKT. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
